
import { Relationship, User } from '../types';
import { authService } from './authService';
import { notificationService } from './notificationService';
import { db } from '@/database';
import { API_BASE } from '../apiConfig';

const API_URL = `${API_BASE}/api/relationships`;

export const relationshipService = {
  // Sync Initial from API
  syncRelationships: async () => {
      try {
          const response = await fetch(API_URL);
          if (response.ok) {
              const data = await response.json();
              if (data.data) {
                  db.relationships.saveAll(data.data);
              }
          }
      } catch (e) {
          console.warn("Relationship sync failed:", e);
      }
  },

  getRelationships: (): Relationship[] => {
    relationshipService.syncRelationships().catch(console.error);
    return db.relationships.getAll();
  },

  followUser: async (targetUsername: string): Promise<'following' | 'requested'> => {
    const currentUserEmail = authService.getCurrentUserEmail();
    if (!currentUserEmail) throw new Error("Usuário não logado");

    const currentUser = authService.getCurrentUser();
    const targetClean = targetUsername.replace('@', '').toLowerCase();
    
    // Privacy check
    const allUsers = db.users.getAll();
    const targetUser = Object.values(allUsers).find(u => u.profile?.name === targetClean);
    
    let status: 'accepted' | 'pending' = 'accepted';
    if (targetUser && targetUser.profile?.isPrivate) {
        status = 'pending';
    }

    const newRel: Relationship = {
        followerEmail: currentUserEmail,
        followingUsername: targetClean,
        status: status
    };

    // --- API CALL FIRST (Reliability) ---
    try {
        const response = await fetch(`${API_URL}/follow`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ followerEmail: currentUserEmail, followingUsername: targetClean, status })
        });
        
        if (!response.ok) throw new Error("Falha ao salvar no servidor");

        // Consolida localmente apenas após sucesso real
        db.relationships.add(newRel);

        // Trigger Notification
        if (targetUser && currentUser) {
            notificationService.addNotification({
                type: status === 'accepted' ? 'follow' : 'pending',
                subtype: status === 'pending' ? 'friend' : undefined,
                username: currentUser.profile?.name || 'Alguém',
                avatar: currentUser.profile?.photoUrl || '',
                text: status === 'accepted' ? 'começou a te seguir.' : 'solicitou para te seguir.',
                recipientEmail: targetUser.email,
                isFollowing: true
            });
        }
        
        return status === 'accepted' ? 'following' : 'requested';

    } catch (e) {
        console.error("Critical: API follow failed", e);
        throw e;
    }
  },

  unfollowUser: async (targetUsername: string) => {
    const currentUserEmail = authService.getCurrentUserEmail();
    if (!currentUserEmail) return;
    
    const targetClean = targetUsername.replace('@', '').toLowerCase();
    
    try {
        const response = await fetch(`${API_URL}/unfollow`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ followerEmail: currentUserEmail, followingUsername: targetClean })
        });
        
        if (!response.ok) throw new Error("Falha ao remover seguidor no servidor");

        db.relationships.remove(currentUserEmail, targetClean);
    } catch (e) {
        console.error("API unfollow failed", e);
        throw e;
    }
  },

  acceptFollowRequest: async (followerHandle: string) => {
      const currentUser = authService.getCurrentUser();
      if (!currentUser || !currentUser.profile?.name) return;

      const myUsername = currentUser.profile.name.toLowerCase();
      const followerClean = followerHandle.replace('@', '').toLowerCase();
      const followerUser = authService.getUserByHandle(followerClean);
      
      if (!followerUser) return;
      const followerEmail = followerUser.email;

      try {
          const response = await fetch(`${API_URL}/follow`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ followerEmail: followerEmail, followingUsername: myUsername, status: 'accepted' })
          });

          if (response.ok) {
              const rel = { followerEmail: followerEmail, followingUsername: myUsername, status: 'accepted' as const };
              db.relationships.add(rel);

              notificationService.addNotification({
                  type: 'follow', 
                  username: currentUser.profile.name,
                  avatar: currentUser.profile.photoUrl || '',
                  text: 'aceitou sua solicitação. Agora você pode ver o perfil.',
                  recipientEmail: followerEmail,
                  isFollowing: true
              });
          }
      } catch (e) {}
  },

  rejectFollowRequest: async (followerHandle: string) => {
      const currentUser = authService.getCurrentUser();
      if (!currentUser || !currentUser.profile?.name) return;

      const myUsername = currentUser.profile.name.toLowerCase();
      const followerClean = followerHandle.replace('@', '').toLowerCase();
      const followerUser = authService.getUserByHandle(followerClean);
      
      if (!followerUser) return;
      const followerEmail = followerUser.email;

      try {
          const response = await fetch(`${API_URL}/unfollow`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ followerEmail: followerEmail, followingUsername: myUsername })
          });

          if (response.ok) {
              db.relationships.remove(followerUser.email, myUsername);
          }
      } catch (e) {}
  },

  isFollowing: (targetUsername: string): 'none' | 'following' | 'requested' => {
    const currentUserEmail = authService.getCurrentUserEmail();
    if (!currentUserEmail) return 'none';
    
    const targetClean = targetUsername.replace('@', '').toLowerCase();
    const rels = db.relationships.getAll();
    
    const rel = rels.find(r => r.followerEmail === currentUserEmail && r.followingUsername === targetClean);
    
    if (!rel) return 'none';
    return rel.status === 'accepted' ? 'following' : 'requested';
  },

  getFollowers: (username: string): { name: string; username: string; avatar?: string }[] => {
    const cleanUsername = username.replace('@', '').toLowerCase();
    const rels = db.relationships.getAll();
    const allUsers = db.users.getAll();

    const followerEmails = rels
        .filter(r => r.followingUsername === cleanUsername && r.status === 'accepted')
        .map(r => r.followerEmail);

    return followerEmails.map(email => {
        const user = allUsers[email];
        if (user && user.profile) {
            return {
                name: user.profile.nickname || user.profile.name,
                username: user.profile.name,
                avatar: user.profile.photoUrl
            };
        }
        return { name: 'Usuário', username: 'user', avatar: undefined };
    });
  },

  getFollowing: (email: string): { name: string; username: string; avatar?: string }[] => {
    const rels = db.relationships.getAll();
    const allUsers = db.users.getAll();

    const followingUsernames = rels
        .filter(r => r.followerEmail === email && r.status === 'accepted')
        .map(r => r.followingUsername);

    const following: { name: string; username: string; avatar?: string }[] = [];
    const usersArray = Object.values(allUsers);

    followingUsernames.forEach(targetUsername => {
        const user = usersArray.find(u => u.profile?.name === targetUsername);
        if (user && user.profile) {
            following.push({
                name: user.profile.nickname || user.profile.name,
                username: user.profile.name,
                avatar: user.profile.photoUrl
            });
        } else {
            following.push({
                name: targetUsername,
                username: targetUsername,
                avatar: undefined
            });
        }
    });

    return following;
  },

  getMutualFriends: async (): Promise<{id: number | string, name: string, username: string, avatar: string}[]> => {
    const currentUserEmail = authService.getCurrentUserEmail();
    if (!currentUserEmail) return [];

    const users = db.users.getAll();
    const myProfile = users[currentUserEmail];
    const myUsername = myProfile?.profile?.name?.toLowerCase();

    if (!myUsername) return [];

    const rels = db.relationships.getAll();

    const iFollowUsernames = rels
        .filter(r => r.followerEmail === currentUserEmail && r.status === 'accepted')
        .map(r => r.followingUsername);

    const usersFollowingMeEmails = rels
        .filter(r => r.followingUsername === myUsername && r.status === 'accepted')
        .map(r => r.followerEmail);

    const mutuals: any[] = [];
    const usersArray = Object.values(users);

    for (const targetUsername of iFollowUsernames) {
        const targetUserEntry = usersArray.find(u => u.profile?.name === targetUsername);
        
        if (targetUserEntry) {
            if (usersFollowingMeEmails.includes(targetUserEntry.email)) {
                mutuals.push({
                    id: targetUserEntry.email,
                    name: targetUserEntry.profile?.nickname || targetUserEntry.profile?.name || 'User',
                    username: targetUserEntry.profile?.name || '',
                    avatar: targetUserEntry.profile?.photoUrl || ''
                });
            }
        }
    }

    return mutuals;
  },

  getTopCreators: async (): Promise<(User & { followerCount: number })[]> => {
      try {
          const response = await fetch(`${API_BASE}/api/rankings/top`);
          if (response.ok) {
              const result = await response.json();
              return result.data || [];
          }
      } catch (e) {
          console.warn("Failed to fetch top creators ranking from server.");
      }
      return []; // Return empty if server fails to ensure consistency
  }
};
